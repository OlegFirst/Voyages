<?php
	//For computer
	$serverName="localhost";
	$userName="user";
	$password="1234";
	$dbName="voyage";
	//For server
	//$serverName="mysql.hostinger.com.ua";
	//$userName="u308305044_user";
	//$password="created";
	//$dbName="u308305044_voyag";
	//Tables
	$table1="placemark";
	$table2="users";
	$table3="security";
?>